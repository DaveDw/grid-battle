GRID BATTLE - Alpha Test Snapshot v0.0.2 (Linux, x86_64)

HOW TO RUN
  tar -xzf GridBattle-Alpha-0.0.2-linux.tar.gz
  ./GridBattle-Alpha-0.0.2.x86_64
  (If it will not start: chmod +x GridBattle-Alpha-0.0.2.x86_64)
  Needs Vulkan or OpenGL 3.3 drivers. Steam Deck: add it as a non-Steam game in Desktop Mode.

CONTROLS
  Keyboard/mouse: WASD move, Q/E swap unit, Space or right-click shoot,
                  1-3 play cards (click a tile to aim), Esc pause.
  Controller:     menus: D-pad + A select, B back.
                  In battle: D-pad move, L1/R1 swap, A shoot, X/Y/B cards,
                  right stick aims, R2 confirms, L2 cancels, Start pause.

WHAT TO TEST
  Pick a leader, clear sectors (3 battles each, the 3rd is a commander),
  draft cards between battles. Win at 3 sectors.
  Tell us: what felt unfair, what felt too easy, cards you never wanted,
  any crash or stuck screen (and what you were doing).
